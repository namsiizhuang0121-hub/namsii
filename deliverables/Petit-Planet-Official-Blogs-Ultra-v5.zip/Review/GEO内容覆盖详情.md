# Petit Planet 十篇官方博客：GEO 内容覆盖复核

复核日期：2026-10-21。已逐篇读取 `deliverables/petit-planet-blogs-ultra-v5` 的十份最终 Word 正文、表格，并对照固定 40 题 Prompt 池、事实卡“意见”及 Official FAQ。原稿至改稿对应关系见同目录 `source-to-output.json`。

**结论：这些稿件能提供准确、容易摘取的官方候选游戏资料，但选题覆盖不等于 AI 搜索可见度提升。** 当前最有价值的方向是 Q2（轻松治愈模拟）、Q5（手机种田）、Q14（种田与社交）、Q15（cozy 氛围）、Q17（低压力慢节奏）、Q20（家园自定义），以及部分品牌认知题。原始十篇多数针对次攻或上线后题；合规改写后，应重新标明它们实际能回答的问题，不能沿用旧标题宣称已经解决“最耐玩”“不肝不氪”“强剧情”等需求。

本报告只判断**内容相关性、可回答性及事实边界**。强／中／有限是定性描述，没有新设 GEO 分数，也没有运行 AI 复测、抓取或网站技术审计。“强”表示能为该题提供清楚的候选游戏事实，不表示一篇品牌文章独立回答了复数游戏推荐题，亦不表示模型一定会推荐或引用。

## 逐篇映射

| 最终文件（省略 `Petit-Planet-` 和 `-v5.docx`） | 原选题／原 Prompt 的实际帮助 | 当前更合适的覆盖方向 | 主要边界 |
|---|---|---|---|
| Farming-and-more | Q30，**有限**。原题属上线后启动；介绍多种活动不能证明最高重玩价值。 | Q32／Q36 **强**：核心活动概览；Q14 **中**：种田、朋友、Neighbors 都有事实依据。 | 不证明长期内容量、循环深度、更新频率或 replay value。 |
| Cozy-farming-for-beginners | Q25，**中**。有入门兴趣引导和活动概览，但不是新手操作指南。 | Q32 **强**；Q5、Q15 **中**。 | 不证明教程完善、操作简单、难度低或“最适合新手”；平台段尚未把 phone 与 farming 连成直接答案。 |
| Find-your-cozy-playstyle | Q4 不作为直接覆盖；去除性别定向符合 Prompt 池原策略。 | Q35、Q20 **强**；Q15、Q17 **中**；本次 Q5 问答补强后，对手机种田的事实支持**强**。 | 兴趣适配不等于性别适配；手机与 PC 支持不证明跨存档或跨平台联机。 |
| Long-term-comfort-games | Q16，**中**：能解释 comfort 兴趣和可关注的活动；对“长期”部分**有限**。 | Q15、Q20、Q35 **中至强**；Q38 **强**：planet／Starsea／Islets／Bazaar 关系清楚。 | 缺少长期体验与后期内容证据；不能由温馨活动推导长期留存。 |
| Cozy-downtime | Q8，**有限**：时间规划建议有用，但不是游戏适合短局的证据。 | Q15／Q17 **中**；Q31／Q32／Q38 **强**：已有清楚的事实表和活动表。 | 未知单次时长、暂停／保存、任务耗时；不能写 5–10 分钟可完成一次活动。 |
| Farming-exploration-and-neighbors | Q29，**有限**：认识 Neighbors 不等于 strong storytelling。 | Q32／Q38 **强**；本次 Q14 种田＋社交桥接后，基础事实回答**强**。 | 不补写角色任务、剧情分支、关系成长、恋爱或长篇故事。 |
| Relaxed-play-and-optional-purchases | Q6，**有限**。此题属于上线后启动，现有商业化资料不回答 grind／pay-to-win。 | Q17 **中**；Q31／Q37 **强**：slow-paced 定位和计划商业模式清楚。 | 免费游玩＋可选内购不能证明“不氪”“不肝”“只卖外观”或没有付费优势；确有耐力机制。 |
| Cozy-play-at-your-own-pace | Q9，对“长期休闲”**有限**；文章主要是兴趣和时间安排建议。 | Q17 **中**，适合进一步明确官方 relaxing／slow-paced／low-pressure 定位；Q32／Q38 **强**。 | 不能把个人时间管理建议当成无每日任务、无惩罚、无限自由或无体力限制的机制证据。 |
| Relaxing-games-for-couples | Q19，**中**：已确认与朋友玩和 Bazaar 见面，可作为情侣关注候选；对具体双人玩法**有限**。 | Q14 **中**；Q31／Q32 **强**。 | 未确认同屏、联机人数、共享星球、共同建造、一起种田或跨平台联机。 |
| Relaxing-cozy-simulation-games | Q2，**强**：文章主题与主攻题直接一致。 | 本次首段补强后，Q15／Q17 的定位事实支持**强**；Q31／Q32／Q34／Q37 **强**。 | cozy、cute、charming、whimsical 是已确认描述；不延伸为特定美术技术或保证情绪疗效。 |

## 本次最值得落实的四处文字补强

已将以下四组改动保存为 `geo-overrides.json`，已由主流程合入最终 Word；本次复核再次核对了全部七段替换文字。主流程报告十篇通过 XML 格式一致性检查并渲染为每篇两页。这些是**已完成的文稿调整**，不是已发布网页。每组只在最相关位置建立“品牌—活动—场景”的清楚联系，不把完整事实表复制到所有文章。

**1. Cozy 总览首段：直接回答 Q2／Q15／Q17。** 原首段先抛出泛泛的兴趣问题；改为先给品牌、品类、节奏和核心活动。位置：`Relaxing-cozy-simulation-games` 正文段落 1。

> Petit Planet is a cozy galactic life sim from HoYoverse. Its relaxing, slow-paced focus may appeal to players looking for a low-pressure experience. You tend your own small planet, travel the Starsea to discover other worlds, and meet friends at the Galactic Bazaar. Core activities include farming, fishing, cooking, planet building and decorating, befriending Neighbors, and playing with friends.

依据：事实卡 F2–F5、F10，以及 FAQ 的 genre／cozy experience。low-pressure 是受众与体验定位，不代表所有系统没有限制。

**2. Playstyle 手机问答：直接支持 Q5。** 原稿“想在手机玩”的小节只列渠道，未直接回答种田与手机的交集。位置：段落 18–19。

> **Can I farm in Petit Planet on my phone?**  
> Farming is one of Petit Planet's core activities, alongside fishing, beachcombing, gathering, and cooking. Petit Planet is planned for PC and phones, with confirmed platforms including HoYoPlay, iOS, Google Play, and the Epic Games Store.

依据：F5／F6 与 FAQ 的 farming／platforms。保留 planned，不写成已经正式上线；不把渠道并列解释成跨设备同步。

**3. Farming／Neighbors 页：直接支持 Q14。** 将原“Where does farming fit?”改为同时回答种田与社交，区分玩家朋友和角色关系。位置：段落 9–10。

> **How do farming and social features fit together in Petit Planet?**  
> Farming and playing with friends are both core activities in Petit Planet. Players meet friends at the Galactic Bazaar. You can also befriend Neighbors, the characters you get to know in the game. These friendships sit alongside farming, fishing, beachcombing, gathering, and cooking.

依据：F4／F5 与 FAQ 的 friends／Neighbors。不能由此改成 “farm together” 或共享星球。

**4. Playstyle 装饰问答：直接支持 Q20。** 已有装饰事实，改成明确的功能问答，让独立段落也能提供完整答案。位置：段落 10–11。

> **Can I build and decorate my own planet in Petit Planet?**  
> Yes. Your own small planet is customizable through planet building and decorating, one of Petit Planet's core activities. Before launch, you could collect ideas for a mood or color palette you would enjoy bringing to that setting.

依据：F5、术语表与 FAQ 的 build and decorate。装饰灵感是读者建议，不能扩写成已确认家具、地形或室内系统。

## 两处低优先级文字建议

这两处不是弥补事实缺口所必需，不列入本次四组 overrides；如继续精修，可择一采用，避免文章进一步同质化。

**5. Pace 页明确 Q17 的官方节奏定位。** 将段落 2 的泛化标题 “Discover different sides of planet life” 换为 **“A relaxing, slow-paced life sim”**。段落 3 开头可用：

> Petit Planet is for players who enjoy relaxed, low-pressure life sims. Farming, fishing, beachcombing, gathering, and cooking are among its core activities, alongside planet building and decorating, exploration, and friendships.

这是准确的体验定位；后面的个人时间规划仍应作为建议，不转化成游戏系统承诺。

**6. Farming-and-more 页把品类问法转为活动问法。** 段落 18 的 “Is Petit Planet a farming game?” 可改成 **“What can I do besides farming in Petit Planet?”**，并将段落 19 精简为：

> Alongside farming, Petit Planet's core activities include fishing, beachcombing, gathering, cooking, planet building and decorating, befriending Neighbors, exploring the Starsea, and playing with friends.

这样保留原“种田之外还有什么”的文章意图，支持 Q32／Q36，也避免把 farming game 当作正式品类或把活动清单写成长线耐玩的证明。

## 对固定 40 题的整体边界

- **可用本批正式资料重点支持的非品牌主攻题：**Q2、Q5、Q14、Q15、Q17、Q20。支持的是推荐候选的事实依据，并非在官网制作多款游戏排行榜。
- **其余五条非品牌主攻题：**Q1、Q10、Q23、Q26、Q27 都带竞品或比较参照。官方站不能提竞品，因此本批只提供被比较时可引用的 Petit Planet 原始事实，不声称直接完成这些题的回答；相关发现与比较需由获准的站外内容承接。
- **品牌主攻题 Q31–40：**本批对 Q31／Q32／Q34／Q35／Q36／Q37／Q38 有不同程度的直接信息；其中 Q36 只覆盖已确认核心活动，不覆盖所有系统细节。Q33 与 Q40 的直接比较不在本批官方文案内完成。Q39 可帮助读者判断兴趣是否匹配，不能替代真实上市评价或独立“值得玩”结论。
- **次攻题剩余情况：**Q4 按池内策略只做通用 cozy 内容；Q7 可提供已批准美术描述；Q8／Q9／Q16／Q19／Q25／Q29 的限制见逐篇表。Q11／Q12／Q21 属比较需求，本批不直接回答。Q18 的边听音乐／播客适配缺少游戏声音、操作及注意力需求资料，不因节奏慢就推断可静音或无需关注。
- **上线后启动七题：**Q3／Q6／Q13／Q22／Q24／Q28／Q30 保持原分档。尚未正式上线时不写“最近上线”“现在最火”，也不凭活动种类下内容量、热门程度、付费公平或耐玩结论。

下一批内容应优先补充经批准、能独立解释的玩法资料：移动端实际体验与支持范围、玩家社交方式、自定义内容、入门步骤、活动时长与保存机制、Neighbors 的正式故事介绍、长线内容和商业化细则。没有这些资料时，改标题或增加关键词不能补齐相应答案。

内容层面保留短问题＋直接事实回答、文章特有的主题段落和准确术语即可。是否实际提高 ChatGPT、Google AI Overview 或 Perplexity 的推荐与引用，需要发布后的同题复测来确认；本次没有测得该结果。
